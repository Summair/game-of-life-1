Overview
========

This repository is designed to create the complete Emdeon TC3 infrastructure on AWS.

Tagging
========

reference from Madhukar, "cloud-TaggingStandard-180815-1048-10.pdf"

The current stakeholders for the tagging standard are:
Enterprise Monitoring (Eric Hand-Smith)
Application Development (Linu Raj / Madhu Bussa)
Sysops Administration (Eric Humphrey)
Cloud Architecture (John Tornblad)

For all:
EC2
EBS
ELB

...need the following tags minimum:

REQUIRED
DONE -> Billing [businessunit].[department].[product].[percent]

DONE -> Name [application name]-[role]-[os]

DONE -> Description [env]/[scope]/[appid]/[comp]/[monitor]


OPTIONAL
AppID
Service



Repository Directories
======================

This repository contains several directories, and each directory contains a README file that describes what it is for in greater detail, and how to use it for managing your systems with Chef.

* `cookbooks/` - Cookbooks you download or create.
* `data_bags/` - Store data bags and items in .json in the repository.
* `roles/` - Store roles in .rb or .json in the repository.
* `environments/` - Store environments in .rb or .json in the repository.

* `sparkleformation/`
 - True 'infrastructure-as-code' implementation: all CloudFormation templates generated programmatically (no need to ever modify JSON directly)
 - Use spreadsheets to describe the subnets and security groups (easy to search and filter ACLs and rules)
 - Not monolithic: application split into multiple stacks for ease-of-use: base vpc "datacenter," "subnets," "securitygroups," and "compute"


Configuration
=============

The config file, `.chef/knife.rb` is a repository specific configuration file for knife. If you're using the Chef Platform, you can download one for your organization from the management console. If you're using the Open Source Chef Server, you can generate a new one with `knife configure`. For more information about configuring Knife, see the Knife documentation.

http://docs.chef.io/knife.html

Next Steps
==========

Read the README file in each of the subdirectories for more information about what goes in those directories.


To Do
=====
* Ensure all seed files are appropriately labeled with the short environment code
* Ensure all seed files are "regenerated" each time an environment is created
* Create "boot_cleanup.rb" that contacts CloudFormation and erases the temp seed files



