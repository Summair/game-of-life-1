Overview
========
"the infrastructure repository": "a discrete collection of provisioning and configuration resources that comprise a complete infrastructure set"
http://www.heavywater.io/blog/2015/04/29/infra-repo/

This repository describes the entirety of the infrastructure, not just an isolated subset.

* Batali - Cookbook requirements of the infrastructure (using Batali)
* CHANGELOG.md - Log of changes
* Gemfile - Local bundle of development tools
* README.md - Description of the repository
* cloudformation/ - Infrastructure provisioning templating resources (using SparkleFormation)
* data_bags/ - Chef data bags
* environments/ - Chef environments
* roles/ - Chef roles
* site-cookbooks/ - Infrastructure specific Chef cookbooks

Workflow
========
1. Setup tool pre-requisites (linux or Mac OSX highly suggested!)

* install the ChefDK omnibus package

* if using BASH (optional): Infrastructure CLI configuration / git clone https://github.com/hw-labs/infra-config
 - (optional) create a localuser account binary directory: mkdir ~/bin
 - (optional) add new local binary dir to PATH inside .profile: export PATH="$PATH:$HOME/bin" # Add localbin PATH for scripting
 - (optional) install rvm: https://rvm.io/rvm/install
 - (optional) install hub (a command line tool that wraps git - place hub executable at: ~/bin/hub): https://github.com/github/hub/releases
 - (optional) set alias for hub inside .profile, AFTER previous localbin PATH modification: eval "$(hub alias -s)"
 - (optional) install direnv (an environment switcher for the shell - place direnv executable at: ~/bin/direnv): https://github.com/zimbatm/direnv/releases
 - (optional) "activate" direnv according to your shell, BASH eg inside ~/.bashrc: eval "$(direnv hook bash)"
 - (optional) install bash-it: git clone https://github.com/bash-it/bash-it.git ~/.bash_it
 - (optional) configure bash-it: ~/.bash_it/install.sh
 - (optional) verify ~/.bash_profile is correct (verify with instructions at https://github.com/hw-labs/infra-config)
 - (optional) install infra-tools plugin: curl -o ~/.bash_it/custom/infra.plugin.bash https://raw.githubusercontent.com/hw-labs/infra-config/master/infra.plugin.bash
 - (optional) link infra-tools plugin: ln -s ~/.bash_it/custom/infra.plugin.bash ~/.bash_it/plugins/enabled/infra.plugin.bash
 - (optional) enable bash-it rvm plugin: bash-it enable plugin rvm
 - (optional) enable infra-tools: echo "infra_commands_enable" >> ~/.bash_profile


 * start with an existing infrastructure framework repository
  - setup new framework repository / git clone git://github.com/hw-labs/infrastructure-repository
  - export AWS_ACCESS_KEY_ID
  - export AWS_SECRET_ACCESS_KEY
  - export AWS_REGION

* set the name of your new infrastructure repository:
  - export REPONAME=test-infra-repo

* export an existing infrastructure repository framework:
  - cd; git clone git://github.com/hw-labs/infrastructure-repository $REPONAME; cd $REPONAME; ls -ltra

* re-initialize framework as a new infrastructure repository
  - cd; mkdir $REPONAME; cd $REPONAME; infra-config

* initialize the new infrastructure repository for use with chef
  - cd; chef generate repo $REPONAME; cd $REPONAME; ls -ltra

* Open the newly created .envrc file and locate the "User edit section" at the top of the file
* edit the AWS_ sections under # AWS
* edit the CHEF sections under # CHEF

* ensure you have the "bundler" gem installed: gem install bundler --no-ri --no-rdoc

* install the necessary gems for the infra framework repo
  - cd; cd $REPONAME; bundle install

* run `batali install` to grab the required cookbooks
  - cd; cd $REPONAME; batali install

* run the `seed` executable shell script to setup the variables necessary for the chef-server
  - cd; cd $REPONAME; ./bin/seed

* NOTE! If you change any of the chef cookbooks, or roles/runlists etc, you MUST re-run the seed to re-create the zip file