tc3-appfabric CHANGELOG
=======================

This file is used to list changes made in each version of the tc3-appfabric cookbook.

0.1.0
-----
- [venkata] - Initial release of tc3-appfabric

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
