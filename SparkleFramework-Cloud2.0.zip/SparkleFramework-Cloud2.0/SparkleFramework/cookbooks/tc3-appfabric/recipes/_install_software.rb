# #
# # Cookbook Name:: tc3-appfabric
# # Recipe:: _install_software
# #
# # Copyright 2015, Innova Solutions USA, Inc.
# #
# # Licensed under the Apache License, Version 2.0 (the "License");
# # you may not use this file except in compliance with the License.
# # You may obtain a copy of the License at
# #
# #     http://www.apache.org/licenses/LICENSE-2.0
# #
# # Unless required by applicable law or agreed to in writing, software
# # distributed under the License is distributed on an "AS IS" BASIS,
# # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# # See the License for the specific language governing permissions and
# # limitations under the License.
# #

windows_service 'wuauserv' do
  action :start  
end

# this was written because in order to install additional appfabric components
# when some are already installed, the entire package must be uninstalled first
#include_recipe 'tc3-appfabric::_uninstall_software'

execute 'WindowsServerAppFabricSetup_x64.exe' do
	cwd node['appfabric']['tempdir']
  command "WindowsServerAppFabricSetup_x64.exe #{node['appfabric']['fullinstaller_installsuffix']}"
  not_if { File.exists?('C:\Program Files\AppFabric 1.1 for Windows Server\Setup.exe') }
	timeout 300
end

windows_service 'wuauserv' do
  action :stop  
end


