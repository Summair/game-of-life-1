#
# Cookbook Name:: tc3-appfabric
# Attributes:: default
#
# Copyright 2015, Innova Solutions USA, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

default['appfabric']['tempdir'] = Chef::Config[:file_cache_path].gsub(::File::SEPARATOR, ::File::ALT_SEPARATOR)
default['appfabric']['fullinstaller'] = 'WindowsServerAppFabricSetup_x64.exe'
#default['main']['s3bucket'] = 'emdeon-dev-tc3-us-east-1'
default['appfabric']['s3path'] = '/applications/tc3health/appsoftware/appfabric'
default['appfabric']['fullinstaller_installsuffix'] = "/i /logfile #{node['appfabric']['tempdir']}\\appfabric_install.log"
# default['appfabric']['fullinstaller_installsuffix'] = '/i CacheClient”,”CachingService”,”CacheAdmin /logfile  C:\temp\appfabric_logFile\appfabric_log.txt'
default['appfabric']['fullinstaller_uninstallsuffix'] = "/r /logfile #{node['appfabric']['tempdir']}\\appfabric_uninstall.log"
