name             'tc3-appfabric'
maintainer       'Innova Solutions USA, Inc.'
maintainer_email 'chef@innovasolutions-usa.com'
license          'Apache 2.0'
description      'Installs/Configures tc3-appfabric'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.0'

depends          'tc3-s3_file', ">= 0.1.0"
depends          'tc3-iis', ">= 0.1.0"
depends          'windows', ">= 1.38.2"




