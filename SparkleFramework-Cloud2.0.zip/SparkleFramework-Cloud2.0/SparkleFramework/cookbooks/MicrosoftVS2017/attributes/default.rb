#
# Author:: Arun Kumar (<arunkumar.bandi@changehealthcare.com>)
# Cookbook Name:: MicrosoftVS2017
# Attributes:: default
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

default['visualstudio']['tempdir'] = Chef::Config[:file_cache_path].gsub(::File::SEPARATOR, ::File::ALT_SEPARATOR)
default['visualstudio']['edition'] = 'professional'
default['visualstudio']['version'] = '2017'
default['visualstudio']['unzip_timeout'] = 1800
default['visualstudio']['s3path'] = '/applications/tc3health/appsoftware/MicrosoftVS2017'
default['visualstudio']['source'] = "#{node['visualstudio']['tempdir']}\\"
default['visualstudio']['enable_nuget_package_restore'] = true
default['visualstudio']['preserve_extracted_files'] = false
include_attribute "MicrosoftVS2017::vs#{node['visualstudio']['version']}"
