#
# Author:: Arun Kumar (<arunkumar.bandi@changehealthcare.com>)
# Cookbook Name:: MicrosoftVS2017
# Attributes:: vs2017
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# Currently you cannot change this, doing so will break the cookbook
#default['visualstudio']['2017']['install_dir'] =
  #(ENV['ProgramFiles(x86)'] || 'C:\Program Files (x86)') +
  #'\Microsoft Visual Studio 15.0'
default['visualstudio']['2017']['install_dir'] =
  'D:\Program Files (x86)\Microsoft Visual Studio\2017\Professional'
default['visualstudio']['2017']['all'] = false
default['visualstudio']['2017']['allWorkloads'] = false
default['visualstudio']['2017']['includeRecommended'] = true
default['visualstudio']['2017']['includeOptional'] = false

# Professional
default['visualstudio']['2017']['professional']['installer_file'] = 'vs_professional.exe'
default['visualstudio']['2017']['professional']['filename'] = 'VS2017PRO.iso'
default['visualstudio']['2017']['professional']['package_name'] = 'Microsoft Visual Studio Professional 2017'

# Community
default['visualstudio']['2017']['community']['installer_file'] = 'vs_community.exe'
default['visualstudio']['2017']['community']['filename'] = 'VS2017COM.iso'
default['visualstudio']['2017']['community']['package_name'] = 'Microsoft Visual Studio Community 2017'
