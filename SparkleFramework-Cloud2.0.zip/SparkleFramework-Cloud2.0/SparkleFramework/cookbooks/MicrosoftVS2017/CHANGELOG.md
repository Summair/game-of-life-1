visual_studio CHANGELOG
==========================

This file is used to list changes made in each version of the visual_studio cookbook.

