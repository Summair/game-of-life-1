name             'MicrosoftVS2017'
maintainer       'Arun Kumar'
maintainer_email 'arunkumar.bandi@changehealthcare.com'
license          'Apache 2.0'
description      'Installs/Configures tc3-visualstudio'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.2'

depends          'tc3-s3_file', ">= 0.1.0"
depends          'visualstudio', ">= 1.2.0"
depends          'tc3-seven_zip', ">= 0.1.0"

