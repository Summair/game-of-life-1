MicrosoftVS2017 Cookbook
=========================
TODO: Installs Microsoft Visual Studio 2017 Professional


Usage
-----
#### MicrosoftVS2017::default


e.g.
Just include `MicrosoftVS2017` in your node's `run_list`:

