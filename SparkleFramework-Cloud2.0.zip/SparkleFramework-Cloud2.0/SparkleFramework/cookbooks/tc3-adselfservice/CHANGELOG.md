tc3-adselfservice CHANGELOG
===========================

This file is used to list changes made in each version of the tc3-adselfservice cookbook.

0.1.1
-----
- [craigs] - Use a single "unified" s3bucket attribute reference, tied to the initial "infrastructure_bucket" CloudFormation template parameter, so that the bucket changes properly regardless of which environment is being used.

0.1.0
-----
- [craigs] - Initial release of tc3-adselfservice

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
