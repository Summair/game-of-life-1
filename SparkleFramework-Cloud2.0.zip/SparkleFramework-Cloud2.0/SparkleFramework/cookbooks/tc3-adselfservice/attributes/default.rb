default['adselfservice']['tempdir'] = Chef::Config[:file_cache_path].gsub(::File::SEPARATOR, ::File::ALT_SEPARATOR)
default['adselfservice']['installer'] = ['ManageEngine_ADSelfService_Plus.exe']
default['adselfservice']['s3path'] = '/applications/tc3health/appsoftware/adselfservice'
default['adselfservice']['installprefix'] = "msiexec /qn /NORESTART /l #{node['adselfservice']['servicename']}.log /i "
default['adselfservice']['servicename'] = 'adselfservice'
