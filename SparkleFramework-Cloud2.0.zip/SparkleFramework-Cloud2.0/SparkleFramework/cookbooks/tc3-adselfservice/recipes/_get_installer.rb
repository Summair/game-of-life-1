# this needs to be included because tc3 outbound web proxy does not work with rubygems
include_recipe 'tc3-s3_file::gem_install'

node['adselfservice']['installer'].each do |i|
  s3_file "#{node['adselfservice']['tempdir']}\\#{i}" do
  	remote_path "#{node['adselfservice']['s3path']}/#{i}"
  	bucket "#{node['main']['s3bucket']}"
  	action :create
    ignore_failure true
    not_if { File.exists?("#{node['adselfservice']['tempdir']}\\#{i}") }
  end
end
