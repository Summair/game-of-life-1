# CHANGELOG for cerberus

This file is used to list changes made in each version of cerberus.

## 2.3.2:

* Add functionality to attempt to download from a local nexus repository and install a pre-built json gem, rather than downloading, building, and installing from RubyGems / the Internet!

## 2.3.1:

* Create new node attribute arrays to hold a list of per-node firewall rules, still using settings from the ip_permit and firewall_rules databags.

## 2.3.0:

* Support arbitary data bag names for ip_permit and firewall_rules, and set the default data bag search pattern to the current node['environment'].

## 2.2.2:

* Minor updates to advfirewall library to send logging to chef, rather than stdout.

## 2.2.1:

* Add support for Windows 2012R2 to default.rb

## 2.2.0:

* Remove chef version compare from cerberus::default in favor of simply running sentry for all Windows 2008R2 machines.  This requires chef-client version > 11 on all Windows 2008R2 machines.

## 0.1.0:

* Initial release of cerberus

- - - 
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
