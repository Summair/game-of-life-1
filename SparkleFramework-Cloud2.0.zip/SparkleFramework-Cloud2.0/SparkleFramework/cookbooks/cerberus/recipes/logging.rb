#
# Cookbook Name:: cerberus
# Recipe:: logging
#
# Copyright 2016, Innova Solutions USA, Inc.
# Copyright 2013, Smashrun, Inc.
# Author:: Steven Craig <chef@innovasolutions.com>
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

if "#{node['firewall']['logging']}" == "true"
  log("enable #{node['firewall']['servicename']} logging dropped connections") { level :debug }
  log("Default log location is: %systemroot%\system32\LogFiles\Firewall\pfirewall.log") { level :debug }
  ["droppedconnections enable", "maxfilesize 32767"].each do |cmdsuffix|
    execute "netsh_logging-enable-#{cmdsuffix}" do
      cwd "#{node['kernel']['os_info']['system_directory']}"
      command "#{node['kernel']['os_info']['system_directory']}\\netsh advfirewall set allprofiles logging #{cmdsuffix}"
      ignore_failure true 
      timeout 30
      action :run
    end
  end
  
else
  log("disable #{node['firewall']['servicename']} logging dropped connections") { level :debug }
  execute "netsh_logging-disable" do
    cwd "#{node['kernel']['os_info']['system_directory']}"
    command "#{node['kernel']['os_info']['system_directory']}\\netsh advfirewall set allprofiles logging droppedconnections disable"
    ignore_failure true 
    timeout 30
    action :run
  end
end