#
# Cookbook Name:: cerberus
# Recipe:: gem_install
#
# Copyright 2015, Innova Solutions USA, Inc.
# Copyright 2013, Smashrun, Inc.
# Author:: Steven Craig <chef@innovasolutions.com>
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

log("begin cerberus::gem_install") { level :debug }
log("running cerberus::cerberus::gem_install") { level :info }

["#{node['firewall']['tempdir']}", "#{node['firewall']['jsonconf']}"].each do |dir|
  directory "#{dir}" do
    action :create
    not_if { File.exists?("#{dir}") }
    recursive true
  end
end

if node['firewall']['nexus_gem']

  node['firewall']['gem'].each do |g|
    
    remote_file "#{node['firewall']['tempdir']}\\#{g['filename']}" do
      source "#{g['nexus_protocol']}://#{g['nexus_hostname']}:#{g['nexus_port']}#{g['nexus_path']}/#{g['filename']}"
      not_if { File.exists?("#{node['firewall']['tempdir']}\\#{g['filename']}") }
    end
  
    chef_gem "#{g['name']}" do
      compile_time false
      clear_sources true
      source "#{node['firewall']['tempdir']}\\#{g['filename']}"
      action :install
      options '--local'
      ignore_failure true
    end
  end

else
  # this does not work properly on 2003, however, it does on 2008
  node['firewall']['gem'].each do |g|
    r = gem_package("#{g['name']}") do
      action :nothing
      version "#{g['version']}" unless g['version'] == nil
    end
    r.run_action(:install)
    Gem.clear_paths
  end

  node['firewall']['gem'].each do |g|
    chef_gem("#{g['name']}") do
      action :install
      version "#{g['version']}" unless g['version'] == nil
    end
  end
end

log("end cerberus::gem_install") { level :info }
