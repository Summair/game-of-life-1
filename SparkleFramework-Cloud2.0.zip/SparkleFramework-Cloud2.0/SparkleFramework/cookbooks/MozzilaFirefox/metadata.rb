name             'MozzilaFirefox'
maintainer       'Arun Kumar Bandi'
maintainer_email 'arunkumar.bandi@changehealthcare.com'
license          'Apache 2.0'
description      'Installs/Configures MozzilaFirefox'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '4.1.1'

depends			 'tc3-s3_file', ">= 0.1.0"
depends          'windows', '>= 3.4.4'




