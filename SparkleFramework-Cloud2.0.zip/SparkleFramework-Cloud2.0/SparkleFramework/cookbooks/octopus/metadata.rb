name             'octopus'
maintainer       'Michael Burns'
maintainer_email 'mike@michaelburns.ca'
license          "Apache 2.0"
description      'installs, configures and registers an octopus tentacle'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.4'
supports         "windows"

depends          "windows", ">= 1.2.2"
# only because CHC's AWS Production Web Proxy server does not work properly
# and therefore every gem must be downloaded and installed manually
depends          'tc3-s3_file', ">= 0.1.0"
