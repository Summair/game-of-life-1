octopus CHANGELOG
=================

0.1.4 (2015-11-24)
------------------
- [PR 4](https://github.com/burnzy/octopus-cookbook/pull/4) - Versioned packages and support for x64 and x86
- Cleanup attribute names to make more readable
- Set default tentacle environment to match chef environment
- [PR 3](https://github.com/burnzy/octopus-cookbook/pull/3) - Add environment if it does not exist


0.1.3 (2015-07-07)
------------------
- Fix README.md for chef supermarket
- [PR 2](https://github.com/burnzy/octopus-cookbook/pull/2) - made name of tentacle an attribute

0.1.2
------------------
- Michael Burns - Cleaned-up cookbook for public release

0.1.0
------------------
- Michael Burns - Initial release of octopus

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
