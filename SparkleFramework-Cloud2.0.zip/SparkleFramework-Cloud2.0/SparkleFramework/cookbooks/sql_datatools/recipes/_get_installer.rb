#
# Cookbook Name:: sql_datatools
# Recipe:: _get_installer
#
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

include_recipe 'tc3-s3_file::gem_install'

s3_file "#{node['ssdt']['tempdir']}\\#{node['ssdt']['filename']}" do
	remote_path "#{node['ssdt']['s3path']}/#{node['ssdt']['filename']}"
	bucket "#{node['main']['s3bucket']}"
	action :create
  ignore_failure true
  not_if { File.exists?("#{node['ssdt']['tempdir']}\\#{node['ssdt']['filename']}") }
end
