#
# Cookbook Name:: sql_datatools
# Recipe:: install_software
#
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#


include_recipe 'sql_datatools::_get_installer'
include_recipe 'sql_datatools::_unzip_installer'

reboot "Installation-of-ssdt-needs-reboot" do
  action :nothing
  reason 'Need to reboot to enable sql server data tools installation!'
end


ruby_block "install_ssdt" do
  block do
    powershell_out "#{node['ssdt']['tempdir']}\\SETUP.exe /install INSTALLALL /quiet /norestart"
	action :create
	end
end