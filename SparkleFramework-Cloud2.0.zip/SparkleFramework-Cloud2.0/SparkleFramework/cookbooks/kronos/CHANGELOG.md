# CHANGELOG for kronos

This file is used to list changes made in each version of kronos.

## 3.1.1
* Bug fix to double check delete tasks are recreated.

## 3.1.0:
* adding an "unless" to not even write out the taskargument into the xml if it is empty.  Also add new "userid" field to the XML so that a userid can be specified for the task.  Also wrap the execute schedule blocks in a rescue.  Also fix the logic first iteration of the userid logic, which was not properly working.  Also, add an "enabled" property to create and disable the task.

## 3.0.0:
* Moving the task list into a node attribute and out of the databag.

## 2.2.2:
* Adding "RestartOnFailure" to restart tasks every five minutes if they fail.

## 2.2.1:
* Adding "executiontimelimit" task modifier for granular control over the permitted task run time limit.

## 2.2.0:
* Adding "onboot" task type, for tasks that should start when the machine does.

## 2.1.0:
* Unsure why version 2.0.3 did not just use the unified "schedule" recipe.  Swapping to that now.

## 2.0.3:
* Remove if statements from default recipe to attempt to detect chef-client version (it does not work properly) and simply run the newer "kronos::delete_2008" and "kronos::schedule_2008" recipes always on Windows 2008R2.  These require chef-client version > 11.

## 2.0.2:
* Bugfix inside delete_2008.rb, add "::" prefix to use ::Win32 to avoid namespace conflict with Chef::Win32 (introduced in Chef 0.10.10)

## 0.1.0:
* Initial release of kronos

- - - 
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
