#
# Cookbook Name:: kronos
# Recipe:: schedule
#
# Copyright 2013, Smashrun, Inc.
# Author:: Steven Craig <support@smashrun.com>
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Task Scheduler Schema
# http://msdn.microsoft.com/en-us/library/windows/desktop/aa383609(v=vs.85).aspx
# Find Active Directory Domain Name from command line:
# http://www.windows-commandline.com/find-domain-name-command-line/
#

log("begin schedule") { level :debug }
log("running schedule") { level :info }

# ensure necessary dirs are setup and available
["#{node['schedule']['tempdir']}", "#{node['schedule']['workingdir']}"].each do |dir|
  # log("create #{dir} directory if necessary") { level :debug }
  directory "#{dir}" do
    action :create
    not_if { File.exists?("#{dir}") }
    recursive true
  end
end

# this is a hack
# ensure simple batch file for file deletion is on the server
log("create delete.bat if necessary") { level :debug }
template "#{node['schedule']['tempdir']}\\delete.bat" do
  source "delete.bat.erb"
  variables({
    :author_name => "#{node['schedule']['author_name']}",
    :author_email => "#{node['schedule']['author_email']}"
  })
  backup false
end


log("Begin registry search for current task list") {level :debug}
# tasks are stored inside two places inside the registry
# find the GUID references by scanning for kronos-* here:
# HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree
regbase = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache'
current_task = []
task_hash = {}

#
# uses new chef client 11 ONLY platform method "registry_get_subkeys" to search for the task keys
# otherwise the 32bit/64bit windows registry monster bites hard
# because on windows 2008 R2 x86_64, task scheduler stores the task keys
# inside the 32-bit registry section (NOT inside the 64bit section!)
# http://docs.opscode.com/dsl_recipe_method_registry_get_subkeys.html
#
# once the keys are found, the value is populated via the new "registry_get_values" method
# http://docs.opscode.com/dsl_recipe_method_registry_get_values.html

subkey_array = registry_get_subkeys("#{regbase}\\Tree", :machine)
subkey_array.each do |k|
  if k =~ /^kronos-/
    #log("found task name #{k}") {level :debug}
    kGUID = registry_get_values("#{regbase}\\Tree\\#{k}", :machine)
    task_hash = {:id => "#{kGUID[0][:data]}", :name => "#{k}"}
    #log("created task hash entry with data #{task_hash.inspect}") {level :debug}
    current_task.push(task_hash)
  end
end
log("End registry search for current task list") {level :debug}
log("Found #{current_task.length.to_s} kronos-managed tasks currently scheduled on #{node[:fqdn].downcase}") {level :info}

# organize tasks
log("Begin search for new or updated tasks to be scheduled") { level :debug }

# running_task holds the comma-separated list of tasks that run on the host
# task_info holds location and file information specific to the individual task
running_task = []
task_info = []

running_task = node['schedule']['task']
running_task.each do |taskname|
  info = {}
  search(:task_info, "id:#{taskname}") do |task|
    info = { "id" => task["id"],
      "taskname" => task["id"],
      "taskrun" => task["taskrun"],
      "taskcommand" => task["taskcommand"],
      "taskargument" => task["taskargument"],
      "schedule" => task["schedule"],
      "modifier" => task["modifier"],
      "starttime" => task["starttime"],
      "executiontimelimit" => task["executiontimelimit"],
      "restartonfailure" => task["restartonfailure"],
      "workingdir" => task["workingdir"],
      "runlevel" => task["runlevel"],
      "userid" => task["userid"],
      "enabled" => task["enabled"],
      "userdatabag" => task["userdatabag"]
    }
    
    unless info["userid"] == nil
      begin
        # add a new variable userdomain if the userid is specified as "user@domain.com" or "domain\user"
        # necessary so that we can name the databag just the name of the useraccount without the domain
        case info["userid"]
        when /^.*\@.*$/
          info["userdomain"] = info["userid"].split('@').last
          # special case: handle situations where we simply want to reference the current AD domain with the format "user@domain"
          if info["userdomain"] =~ /^domain$/i
            #info["userdomain"] = "#{node['activedirectory']['netbiosname']}#{node['activedirectory']['domaintld']}"
            domainquery = `wmic computersystem get domain`.chomp.split(/\n/).last.split('.').first
            log("wmic computersystem get domain results: #{domainquery}") {level :debug}
            info["userdomain"] = domainquery
          end
          info["userlookup"] = info["userid"].split('@').first
        when /^.*\\.*$/
          info["userdomain"] = info["userid"].split('\\').first
          # special case: handle situations where we simply want to reference the current AD domain with the format "user@domain"
          if info["userdomain"] =~ /^domain$/i
            domainquery = `wmic computersystem get domain`.chomp.split(/\n/).last.split('.').first
            log("wmic computersystem get domain results: #{domainquery}") {level :debug}
            info["userdomain"] = domainquery
            #info["userdomain"] = "#{node['activedirectory']['netbiosname']}"
          end
          info["userlookup"] = info["userid"].split('\\').last
        else
          info["userdomain"] = nil
          info["userlookup"] = info["userid"]          
        end

        secret = Chef::EncryptedDataBagItem.load_secret("#{node['schedule']['databag_secret']}")
        settings = Chef::EncryptedDataBagItem.load("#{info["userdatabag"]}", "#{info["userlookup"]}", secret)
        info["password"] = settings["password"]
      rescue StandardError => e
        Chef::Log.info "Error retrieving the password for #{info["userlookup"]} from databag #{info["userdatabag"]}."
        Chef::Log.info "The task will be registered Under Local System until this error is resolved: #{e.inspect}"
        info["userid"] = nil
      end
    end
    
  end
  task_info << info

  log("End search for new or updated tasks to be scheduled") { level :debug }
  log("Found #{node['schedule']['task'].length.to_s} tasks inside authoritative node attribute") {level :info}
end #get running_task

log("Begin deprecated Task removal, if necessary") {level :debug}
# first, build the "remove" list of tasks we know must be removed this run
# (because they no longer exist inside the authoritative chef data bag)
remove = current_task.collect {|x| "#{x[:name].gsub(/^kronos-/,'')}"} - running_task
unless remove.length == 0
  log("Found #{remove.length} currently scheduled, kronos-managed tasks to be removed this run") {level :info}
end

# tasks inside the "remove" array need to be unregistered via task scheduler
remove.each do |d|
  execute "delete-task-registration-#{d}" do
    cwd "#{node['schedule']['workingdir']}"
    command %Q(#{node[:kernel][:os_info][:system_directory]}\\schtasks.exe /delete /tn kronos-#{d} /F)
    action :run
    timeout 60
    ignore_failure true
  end
end

# next, find any orphaned task xml files that might be "left-over" inside the task directory
# this list could (and should, in most cases) overlap with the "remove" list
# but if there is an unclean run, or - more likely - if a person mucked about
# with the registry, or the chef cache, or the task scheduler wizard, this will clean that up, too
orphan = []
begin
  if node['schedule']['workingdir']
    Dir.chdir(node['schedule']['workingdir'])
    file = Dir["*"].reject{|o| File.directory?(o)}
    t = file.collect {|x| x.gsub(/\.xml$/,'')}
    #running_task.map!{|x| x + ".xml"}
    orphan = t - running_task
  else
    puts "node['schedule']['workingdir'] is required"
  end
rescue Exception => e
  Chef::Log.warn("Error in cookbook kronos::schedule #{e}")
  Chef::Log.warn("This is expected behaviour on the initial run #{e}")
end

unless orphan.length == 0
  log("Found #{orphan.length} orphaned, kronos-managed xml task files to be removed this run") {level :info}
end

# last, add the remove and orphan lists together and unique them
# so that the contents can be deleted from the node
# known tasks for removal will need their xml files deleted
# unknown xml files could also potentially accumulate and could require removal as well
delete = remove + orphan
delete.uniq!
unless delete.length == 0
  log("Deleting #{delete.length} kronos-managed xml task files inside #{node['schedule']['workingdir']}") {level :info}
end
delete.each do |d|
  execute "delete-task-file-#{d}.xml" do
    cwd "#{node['schedule']['workingdir']}"
    command %Q(del /F /S /Q "#{node['schedule']['workingdir']}\\#{d}.xml")
    action :run
    timeout 60
  end
end

log("End deprecated Scheduled Task removal") {level :debug}

# now create and update individual xml files, one per task
task_info.each do |task|

  # just saw some strangeness where there might be an empty item inside the node attribute array
  # if that happens, this should skip it.
  if task["id"] == nil
    log("If you see: execute[schedule-.xml] in logs, it means your task is missing from the task_info data bag!") { level :warn }
    log("Make sure you have added the task to the task_info databag!") { level :warn }
  else
    # schedule each task on notification from template
    # if the userid is nil, do not specify a password and use LocalSystem
    # otherwise there must be a userid, but it could be a local user,
    # so check to see if the userdomain exists
    # if userdomain doesn't exist, it is a local user so just specify the userid
    # lastly, it must be a domain account so specify domain\user
    begin
      case
      when task["userid"] == nil
        execute "schedule-#{task["id"]}.xml" do
          cwd "#{node['schedule']['workingdir']}"
          command %Q(#{node[:kernel][:os_info][:system_directory]}\\schtasks.exe /create /tn kronos-#{task["id"]} /xml #{node['schedule']['workingdir']}\\#{task["id"]}.xml /F)
          action :nothing
          timeout 60
        end
      when task["userdomain"] == nil
        execute "schedule-#{task["id"]}.xml" do
          cwd "#{node['schedule']['workingdir']}"
          command %Q(#{node[:kernel][:os_info][:system_directory]}\\schtasks.exe /create /RU #{task["userid"]} /RP #{task["password"]} /tn kronos-#{task["id"]} /xml #{node['schedule']['workingdir']}\\#{task["id"]}.xml /F)
          action :nothing
          timeout 60
        end
      else
        execute "schedule-#{task["id"]}.xml" do
          cwd "#{node['schedule']['workingdir']}"
          command %Q(#{node[:kernel][:os_info][:system_directory]}\\schtasks.exe /create /RU #{task["userdomain"]}\\#{task["userlookup"]} /RP #{task["password"]} /tn kronos-#{task["id"]} /xml #{node['schedule']['workingdir']}\\#{task["id"]}.xml /F)
          action :nothing
          timeout 60
        end
      end
    rescue Exception => e
      Chef::Log.warn("Error in cookbook kronos::schedule #{e}")
    end

    # chef version branches 0.10.z and 10.y.z and 11.y.z handle templates differently
    # unsure exactly what has changed but performance absolutely declined in new branch
    time = Time.new
    windate = time.strftime("%Y-%m-%d")
    wintime = time.strftime("%H:%M:%S")

    templated = nil
    begin
      templated = resources(:template => "#{node['schedule']['basexml_template']}")
    rescue Chef::Exceptions::ResourceNotFound
      templated = template "#{node['schedule']['workingdir']}\\#{task["id"]}.xml" do
        source "#{node['schedule']['basexml_template']}"
        backup false
        variables({
          :task_info => task,
          :windate => windate,
          :wintime => wintime,
          :author_name => "#{node['schedule']['author_name']}",
          :author_email => "#{node['schedule']['author_email']}",
          :basexml => "#{node['schedule']['basexml']}",
          :basexml_template => "#{node['schedule']['basexml_template']}",
          :baselog => "#{node['schedule']['baselog']}",
          :basewiki => "#{node['schedule']['basewiki']}",
          :system_dir => "#{node[:kernel][:os_info][:system_directory]}"
        })
        notifies :run, resources(:execute => "schedule-#{task["id"]}.xml"), :immediately
      end
    end
  end
end

# on windows 2008, if the template does not change, chef does not reload the task
# this is nice for efficiency; however, it means that if someone deletes the task locally,
# the node[:schedule][:workingdir] folder would need to be deleted before chef would re-create them
# the "double-check" ensures these are re-registered each run
double_check = running_task - current_task.collect {|x| "#{x[:name].gsub(/^kronos-/,'')}"}
double_check.each do |task|

  case
  when task["id"] == nil
    log("If you see: execute[schedule-.xml], it means your task defination is missing from the task_info data bag!") { level :warn }
    log("Make sure you have added the task to the task_info databag!") { level :warn }
  when "#{task["userid"]}" == nil
    execute "schedule-#{task["id"]}.xml" do
      cwd "#{node['schedule']['workingdir']}"
      command %Q(#{node[:kernel][:os_info][:system_directory]}\\schtasks.exe /create /tn kronos-#{task["id"]} /xml #{node['schedule']['workingdir']}\\#{task["id"]}.xml /F)
     # action :nothing
      timeout 60
    end
  when "#{task["userdomain"]}" == nil
    execute "schedule-#{task["id"]}.xml" do
      cwd "#{node['schedule']['workingdir']}"
      command %Q(#{node[:kernel][:os_info][:system_directory]}\\schtasks.exe /create /RU #{task["userid"]} /RP #{task["password"]} /tn kronos-#{task["id"]} /xml #{node['schedule']['workingdir']}\\#{task["id"]}.xml /F)
     # action :nothing
      timeout 60
    end
  else
    execute "schedule-#{task["id"]}.xml" do
      cwd "#{node['schedule']['workingdir']}"
      command %Q(#{node[:kernel][:os_info][:system_directory]}\\schtasks.exe /create /RU #{task["userdomain"]}\\#{task["userlookup"]} /RP #{task["password"]} /tn kronos-#{task["id"]} /xml #{node['schedule']['workingdir']}\\#{task["id"]}.xml /F)
     # action :nothing
      timeout 60
    end
  end
end


log("end schedule") { level :info }
