# CHANGELOG for reginjector

This file is used to list changes made in each version of reginjector.

## 0.3.0:

* [craigs] Add attribute to set the template cookbook name in order to conform with the wrapper cookbook pattern.

## 0.2.6:

* [craigs] No changelog entry.

## 0.1.0:

* [craigs] Initial release of reginjector


- - - 
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
