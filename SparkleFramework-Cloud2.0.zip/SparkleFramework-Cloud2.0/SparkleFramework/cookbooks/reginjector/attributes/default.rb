#
# Cookbook Name:: reginjector
# Attributes:: default
#
# Copyright 2010, Smashrun, Inc.
# Copyright 2015, Innova Solutions, Inc.
# Author:: Steven Craig <chef@innovasolutions.com>
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

case node[:platform]
when 'windows'

  default['reginjector']['payload'] = []
  default['reginjector']['template_cookbook'] = 'reginjector'
  default['reginjector']['regeditor_version'] = 'Windows Registry Editor Version 5.00'

  default['reginjector']['databag_secret'] = 'C:\\Chef\\encrypted_data_bag_secret'
  default['reginjector']['tempdir'] = Chef::Config[:file_cache_path].gsub(::File::SEPARATOR, ::File::ALT_SEPARATOR)
  default['reginjector']['workingdir'] = "#{node['reginjector']['tempdir']}\\registry_injection"

when 'centos','redhat','fedora','ubuntu','debian','arch'
  default['reginjector']['databag_secret'] = '/etc/chef/encrypted_data_bag_secret'
end
