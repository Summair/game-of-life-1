Description
===========

It is a straightforward exercise to manage windows registry changes by either exporting or just writing out the registry changes to templates and then using a batch file wrapper around regedit to inject them into the registry.  Updates to the registry files will cause them to be reinjected.  Batch file was necessary for early versions of chef and windows; later versions of chef and windows work with the new "batch" resource.

Requirements
============

This cookbook does not have any other dependencies than regedit.  It should work on all versions of windows, without exception.  Versions of this cookbook prior to 0.2.0 did not work properly with 64bit windows OS'; however, that has been fixed with Chef version 11.6.0+ and reginjector >= 0.2.0.  Note that if UAC is enabled, and chef-client is running as a windows service, this cookbook will fail to operate.

Attributes
==========

Minimal.  Deploy a small number of registry changes across the board stored in an attribute array on the nodes.

Usage
=====

Set the template_cookbook attribute to match the name of your wrapper cookbook, if you have one. Add appropriately formatted .reg files to the templates directory, and then update the payload array node attribute to deploy them. Add the default recipe to your run_list.
