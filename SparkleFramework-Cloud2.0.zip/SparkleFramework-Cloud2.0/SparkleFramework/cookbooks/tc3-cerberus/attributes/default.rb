#
# Author:: Steven Craig <chef@innovasolutions.com>
# Cookbook Name:: tc3-cerberus
# Attributes:: default
#
# Copyright 2016, Innova Solutions USA, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

default['firewall']['s3path'] = '/applications/tc3health/appsoftware/chef'
default['firewall']['nexus_gem'] = true

if node['firewall']['nexus_gem']
  default['firewall']['gem'] = [
    { 'name' => 'json',
      'filename' => 'json-1.8.3-x64-mingw32.gem',
      'nexus_protocol' => 'https',
      'nexus_hostname' => 'nexus.emdeon.net',
      'nexus_port' => '8443',
      'nexus_path' => '/nexus/content/sites/Emdeon-TC3-Health'
    }
  ]
else
  default['firewall']['gem'] = [
    { 'name' => 'json' }
  ]
end

# set these all to false by default
# but ensure they can be changed environment-wide if necessary
case
when node.chef_environment =~ /^dev/i
  default['firewall']['logging'] = 'true'
when node.chef_environment =~ /^imp/i
  default['firewall']['logging'] = 'true'
when node.chef_environment =~ /^qa/i
  default['firewall']['logging'] = 'true'
when node.chef_environment =~ /^cert/i
  default['firewall']['logging'] = 'true'
when node.chef_environment =~ /^prod/i
  default['firewall']['logging'] = 'true'
when node.chef_environment =~ /^dr/i
  default['firewall']['logging'] = 'true'
when node.chef_environment =~ /^test/i
  default['firewall']['logging'] = 'true'
else
  default['firewall']['logging'] = 'false'
end

### ALl rules now in environment-specific file for easier diff-ing
### diff -wEBb ./attributes/development.rb ./attributes/implementation.rb | mate

