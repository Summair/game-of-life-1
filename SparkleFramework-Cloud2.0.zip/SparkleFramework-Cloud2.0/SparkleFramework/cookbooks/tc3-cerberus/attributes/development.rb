#
# Author:: Steven Craig <chef@innovasolutions.com>
# Cookbook Name:: tc3-cerberus
# Attributes:: development
#
# Copyright 2016, Innova Solutions USA, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
allow = []

case

when node.chef_environment =~ /^dev/i

  allow = [
    { 'id' => ['octopus'], 'port' => ['10933']},
    { 'id' => ['developmentcidr-1', 'developmentcidr-2', 'changehealthcare_vdi', 'changehealthcare_vpn1', 'changehealthcare_vpn2', 'tc3_workstation6'], 'port' => ['3389']}
  ]

  if node.roles.include?('windows_domain_controller_fw_rules')
    allow = allow + [
      { 'id' => ['infoblox1', 'infoblox2'], 'port' => ['53']},
      { 'id' => ['developmentcidr-1', 'developmentcidr-2', 'softnas'], 'port' => ['53', '88', '123', '135', '137-139', '389', '445', '464', '636', '3268-3269', '49152-65535']}
    ]
  end

  if node.roles.include?('windows_domain_controller')
    allow = allow + [
      { 'id' => ['infoblox1', 'infoblox2'], 'port' => ['53']},
      { 'id' => ['developmentcidr-1', 'developmentcidr-2', 'softnas'], 'port' => ['53', '88', '123', '135', '137-139', '389', '445', '464', '636', '3268-3269', '49152-65535']}
    ]
  end

  if node.roles.include?('windows_base_mssql')
    allow = allow + [
      { 'id' => ['developmentcidr-1', 'developmentcidr-2', 'changehealthcare_vdi', 'changehealthcare_vpn1', 'changehealthcare_vpn2', 'tc3_workstation1', 'tc3_workstation2', 'tc3_workstation3', 'tc3_workstation4', 'tc3_workstation5', 'tc3_workstation6'], 'port' => ['80']},
      { 'id' => ['development_database1', 'development_database2', 'development_database3'], 'port' => ['135', '137-139', '445', '3343', '5022', '5985']},
      { 'id' => ['developmentcidr-1', 'developmentcidr-2', 'changehealthcare_vdi', 'octopus'], 'port' => ['1433-1434']},
      { 'id' => ['developmentcidr-1', 'developmentcidr-2'], 'port' => ['5000-5100']}
    ]
  end

  if node.roles.include?('windows_cluster_witness')
    allow = allow + [
      { 'id' => ['development_database1', 'development_database2', 'development_database3'], 'port' => ['135', '137-139', '445', '3343', '5022', '5985']}
    ]
  end

  if node.roles.include?('windows_base_eac')
    allow = allow + [
      { 'id' => ['iamterminal'], 'port' => ['3389']},
      { 'id' => ['identityiq'], 'port' => ['5050-5060']}
    ]
  end

  if node.roles.include?('windows_base_passwd')
    allow = allow + [
      { 'id' => ['developmentcidr-1', 'developmentcidr-2', 'changehealthcare_vdi'], 'port' => ['8888']}
    ]
  end

  if node.roles.include?('windows_base_iis')
    allow = allow + [
      { 'id' => ['developmentcidr-1', 'developmentcidr-2', 'changehealthcare_vdi', 'changehealthcare_vpn1', 'changehealthcare_vpn2'], 'port' => ['80','443']},
      { 'id' => ['developmentcidr-1', 'developmentcidr-2', 'changehealthcare_vdi', 'changehealthcare_vpn1', 'changehealthcare_vpn2'], 'port' => ['8443-8449', '18443-18446']},
      { 'id' => ['changehealthcare_vdi'], 'port' => ['4018-4019']}
    ]
  end

  if node.roles.include?('windows_base_cache')
    allow = allow + [
      { 'id' => ['developmentcidr-1', 'developmentcidr-2'], 'port' => ['22233','22234','22235','22236']}
    ]
  end

  if node.roles.include?('windows_base_app')
    allow = allow + [
      { 'id' => ['developmentcidr-1', 'developmentcidr-2', 'changehealthcare_vdi', 'changehealthcare_vpn1', 'changehealthcare_vpn2', 'tc3_workstation6'], 'port' => ['80','443']},
      { 'id' => ['changehealthcare_vdi'], 'port' => ['4018-4019']}
    ]
  end

  default['firewall']['rules'] = allow

end
