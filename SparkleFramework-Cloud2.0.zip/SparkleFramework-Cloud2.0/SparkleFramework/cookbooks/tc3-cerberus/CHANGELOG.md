tc3-cerberus CHANGELOG
======================

This file is used to list changes made in each version of the tc3-cerberus cookbook.

0.1.3
-----
- [toups] - Update to development.rb to point to the two new CIDR blocks for PrePay Development Environment

0.1.2
-----
- [craigs] - Use remote_file to retrieve gems from nexus and remove dependency on s3_file cookbook.

0.1.1
-----
- [craigs] - This adds ports 18* for HTTPS web application access.

0.1.0
-----
- [craigs] - Initial release of tc3-cerberus, wrapper for public cerberus cookbook.

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
