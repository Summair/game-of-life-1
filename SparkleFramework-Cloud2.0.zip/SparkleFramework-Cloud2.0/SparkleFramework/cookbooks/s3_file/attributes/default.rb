default['s3_file']['rest-client']['version'] = '1.7.3'
