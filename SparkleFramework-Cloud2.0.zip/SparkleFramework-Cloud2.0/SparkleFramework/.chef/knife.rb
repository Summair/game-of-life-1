# QA
current_dir = File.expand_path(File.dirname(__FILE__))
root_dir = File.dirname(current_dir)

log_level :info
log_location STDOUT

# chef_server_url 'https://internal-tc3-prod-ChefLoad-8J17JIL9KO9R-382199267.us-east-1.elb.amazonaws.com/organizations/tc3'
#chef_server_url 'https://internal-tc3-TEST-ChefLoad-1GHQ1NIBEZKLQ-2106697259.us-east-1.elb.amazonaws.com/organizations/tc3'
chef_server_url 'https://internal-prepay-ch-prepayCh-WQR5H3Z50QMJ-1439057383.us-east-1.elb.amazonaws.com/organizations/tc3'
#chef_server_url 'https://internal-tc3-test-ChefLoad-1HP7THST1F25C-1342000287.us-east-1.elb.amazonaws.com/organizations/internal-prepay-ch-prepayCh-L6KDBTBC3DOZ-1943810685.us-east-1.elb.amazonaws.comtc3'
chef_repo_path root_dir
cookbook_path File.join(root_dir, 'cookbooks')

node_name ENV.fetch('KNIFE_USER', 'jelee')
client_key ENV.fetch('KNIFE_CLIENT_KEY', 'C:\code\tc3_infrastructure\SparkleFramework\.chef\jelee-QCI.pem')
#client_key ENV.fetch('KNIFE_CLIENT_KEY', 'jlee-PROD07182016.pem')

# Encrypted data bag items
knife[:secret_file] = ENV['SECRET_FILE']

# AWS credentials
knife[:aws_access_key_id] = ENV['AWS_ACCESS_KEY_ID']
knife[:aws_secret_access_key] = ENV['AWS_SECRET_ACCESS_KEY']
knife[:region] = ENV['AWS_REGION']

knife[:editor] = '"C:\Program Files\Sublime Text 3\sublime_text.exe" --wait'
